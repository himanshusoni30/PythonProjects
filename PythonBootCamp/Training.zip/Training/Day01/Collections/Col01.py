from collections import deque

q = deque(open('Gen03.py'),3) #head -3 
for line in q:
    print(line, end='')