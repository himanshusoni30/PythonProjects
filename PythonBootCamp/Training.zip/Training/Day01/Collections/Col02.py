from collections import Counter
from random import randint
items = [randint(1, 10) for item in range(100)]
c = Counter(items)
for item in sorted(c):
    print(item, '->', c[item])