"""functional programming"""

items = [2, 1, 3, 4, 5, 6, 4]
m = map(hex, items) #map is a python's build in function for practicing functional programming
print(m)

for item in m:
    print(item)