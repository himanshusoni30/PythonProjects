"""
112

<ascii  char="p">112</ascii>
"""

def tag_it(av):
    return '<ascii char="{}">{}</ascii>'.format(chr(av),av)

ascii_values = [112, 101, 116, 101, 114, 32, 112, 97, 110]
m = map(tag_it,ascii_values)
m = map(lambda av: '<ascii char="{}">{}</ascii>'.format(chr(av),av), ascii_values)

for tag in m:
    print(tag)