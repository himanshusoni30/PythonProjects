XS = [4, 3, 2, 1]
NS = [1, 2, 3, 4]

for item in map(lambda x, n: x**n, XS, NS):
    print(item)