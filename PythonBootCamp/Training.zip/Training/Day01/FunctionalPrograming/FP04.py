items = list(range(1,200))
print items

m = map(lambda arg: arg % 7 == 0, items)
print(list(m))

m = filter(lambda arg: arg % 7 == 0, items)
#select only those values for which lambda function expression is TRUE
print(list(m))