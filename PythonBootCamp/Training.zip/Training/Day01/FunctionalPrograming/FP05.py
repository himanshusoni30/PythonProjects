import re

#s='the python and the perl scripting'
#print(re.search('P.+N',s,re.I))

pattern = 'lambda'
m = filter(lambda line: re.search(pattern, line), open('FP05.py'))
for matched_line in m:
    print(matched_line, end='')