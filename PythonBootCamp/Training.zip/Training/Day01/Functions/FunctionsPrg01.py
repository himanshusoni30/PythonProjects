#Fixed arguments/ positional argument
"""TypeError: power() takes exactly 2 arguments (1 given)"""
def power(x,n):
    return x ** n

print(power(3,2))
print(power(3))
