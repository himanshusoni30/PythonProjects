def demo(*args):
    """variable length argument parameter"""
    print(args)

demo()
demo(100) #gives single element tuple
demo(1,2,'iii',4,5.5) #tuple

items = [1.1,2,3,4,5,6]
demo(items) #gives tuple of list
demo(*items) #calling the function with contents of items's object

items = (1,2,3,4,5)
demo(items) #gives tuple of tuple
demo(*items)