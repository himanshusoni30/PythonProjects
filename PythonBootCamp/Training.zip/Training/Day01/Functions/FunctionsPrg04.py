#Keyword argument parameter
#it is passed as **kwargs unlike normal argument *args

def tuner(**kwargs):
    print(kwargs)

tuner()
tuner(brightness=0.8, contrast=0.98, hue=.78) #this will return dictionary