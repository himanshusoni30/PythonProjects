def demo(a, b, *args, **kwargs):
    print(a)
    print(b)
    print(args)
    print(kwargs)

demo(12,13)
demo(12,13,lang='perl', auth='Larry')#returns kwargs in dictionary

demo(12,13,1,2,3,lang='perl', auth='Larry') # 1,2,3 (args)
# will be returned in tuples, and kwargs in dictionary

#demo(12,13,lang='perl', auth='Larry',10) #compilation error SyntaxError: non-keyword arg after keyword arg