n = 100 #global scope

def demo():
    global n
    print(n)
    x = 10 #local variable
    print(x)
    n = 'pip'
    # global n
    #instead of creating local variable please refer global version of n
    # global keyword is used to update the value of global variable and it will be local to that function

    print(n)

demo()
