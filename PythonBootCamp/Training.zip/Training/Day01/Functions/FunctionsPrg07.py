counter = 0 #used as static variable

def demo():
    global counter
    counter += 1

demo()
demo()
demo()
print(counter)