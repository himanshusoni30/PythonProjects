#named functions
def demo(a, b):
    print(a + b)

print(demo)
print(type(demo))