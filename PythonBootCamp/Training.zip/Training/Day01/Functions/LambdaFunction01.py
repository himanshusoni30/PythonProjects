"""Syntax for lambda function

lambda arg1, arg2, ......: expression
(lambda functions cannot be more than 1 line)
"""

power=lambda x, n: x ** n
#power=lambda x, n=0: x ** n -- variable values can also be passed in lambda
print(power)
print(type(power))
print(power(4,5))
print(power(4))