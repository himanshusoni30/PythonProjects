""" Generator functions, if a function contains a keyword 'yield' then function is called Generator Functions."""
def demo():
    
    print('before 1')
    yield 123
    print('after 1')
    
    print('before 2')
    yield 12.21
    print('after 2')
    
    print('before 3')
    yield 'pam'
    print('after 3')
    
g = demo()
for item in g:
    print(item)
    print('-'*22)
    