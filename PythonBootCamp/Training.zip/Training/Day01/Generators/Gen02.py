
def get_integers():
    """infinite stream"""
    i=1
    
    while True:
        yield i
        i += 1
        
square = (item ** 2 for item in get_integers())

def take_n(seq,n):
    while n:
        yield next(seq)
        n -= 1
        
for item in take_n(square,5):
    print(item)
