from os import walk
from os.path import join
from pprint import pprint as pp
import re

def findFiles(directory_name, search_pattern=None):
    for dirpath, dirnames, filenames in walk(directory_name):
        for matched_file_name in filter(lambda file_name: re.search(search_pattern, file_name),filenames):
            yield join(dirpath, matched_file_name)
            
g = findFiles(r'D:\Userfiles\hsoni\Downloads', '.pdf$')

for pys in g:
    print(pys)