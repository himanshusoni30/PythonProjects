"""list comprehension"""
from timeit import timeit

def demo1():
    items = [112, 101, 116, 101, 114, 32, 112, 97, 110]
    temp=[]
    
    for item in items:
        temp.append(oct(item))
        
    return temp

def demo2():
    items = [112, 101, 116, 101, 114, 32, 112, 97, 110]
    temp2=[oct(item) for item in items] #list comprehension
    return temp2

print('execution time',timeit('demo1()', setup='from __main__ import demo1', number=100000)) 
print('execution time',timeit('demo2()', setup='from __main__ import demo2', number=100000)) 