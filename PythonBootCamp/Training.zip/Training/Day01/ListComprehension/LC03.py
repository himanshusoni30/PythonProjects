""" pass function as argument in function """

def my_filter(func,iter_obj):
    return [item for item in iter_obj if func(item)] #returns list comprehension
    
content=my_filter(lambda n: n%7 == 0, range(1,199))
print(content)

content=my_filter(lambda char: char not in 'aeiou ', 'this is a sample string in python')
print(content)