temp = [bin(item) for item in range(10)] # List comprehensions
print('List Comprehensions:',temp)
print(type(temp))
print()

temp2 = {item: bin(item) for item in range(10)} # Dictionary Comprehensions
print('Dictionary Comprehensions:',temp2)
print(type(temp2))
print()

temp3 = {bin(item) for item in range(10)} # Set Comprehensions
print('Set Comprehensions:',temp3)
print(type(temp3))
print()

"""the only difference between Dictionary and Set Comprehensions is that Dictionary has key but 
Set does not"""

temp = (bin(item) for item in range(100000000000000)) #Generator is a python object to define a custom iterator
print(type(temp))

"""define iterable objects in python using Generator"""