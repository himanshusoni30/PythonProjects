from itertools import zip_longest

names = ['sam','tim','pam','tom']
age = [3,2,4,1]
gender = ['male','male','female','male']

#parallel iterate
print(zip(names,age,gender))
print(list(zip(names,age,gender)))

for item in zip(names,age,gender):
    print(item)
    
names = ['sam','tim','pam','tom']
age = [3,2,4]
gender = ['male','male','female','male']

#parallel iterate
print(zip_longest(names,age,gender))
print(list(zip_longest(names,age,gender)))

for item in zip_longest(names,age,gender):
    print(item)