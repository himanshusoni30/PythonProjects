import math
import os
import sys

class SystemInformation:
    pass

si = SystemInformation()
print(si)
print(SystemInformation)
print(__name__) #default namespace of python script and modules
print(math.__name__)
print(os.__name__)
print(sys.__name__)
