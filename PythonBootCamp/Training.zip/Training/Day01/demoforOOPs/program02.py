class SystemInformation:
    # define constructor
    def __init__(self):
        print(self, 'i am in constructor') #self assigns the reference of current object just like this keyword in Java
    
    #define destructor
    def __del__(self):
        print(self, 'i am getting destroyed...')
        
si = SystemInformation() #object creation
print(si)