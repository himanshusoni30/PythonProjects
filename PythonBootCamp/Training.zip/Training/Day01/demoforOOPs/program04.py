class PackageManager:
    def __init__(self,name,version):
        self.__name=name      #private member, public can be changed to private using __
        self.version=version
        
    def __get_information(self): #private method
        print('name: ', self.__name)
        print('version: ', self.version)
        
    def wrapper(self):
        self.__get_information()   #calling private method using public

""" objects that are created in python are always outside the scope of class, so in order to access the private methods of class,
public methods should be used to invoke private methods"""

pm = PackageManager('pip', '2.2.18')
pm.wrapper()    #invoke function using object
