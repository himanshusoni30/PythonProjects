def timer(func):
    from time import perf_counter
    def wrapper_timer(*args):
        start = perf_counter()
        return_value = func(*args)
        end = perf_counter()
        elapsed = end - start
        print('finished {}{} in {}'.format(func.__name__, args, elapsed))
        return return_value
    return wrapper_timer

def slow_down(func):
    from time import sleep
    def wrapper_slow_down(*args): # from wrapper original function need to be called.
        sleep(1)
        return func(*args)
    
    return wrapper_slow_down

#@timer
@slow_down
def count_down(counter):    
    if counter:
        print(counter)
        count_down(counter - 1)
    else:
        print('lift-off...')    
        
#count_down = timer(slow_down(count_down))    

if __name__ == '__main__':
    print(count_down)
    count_down(3)