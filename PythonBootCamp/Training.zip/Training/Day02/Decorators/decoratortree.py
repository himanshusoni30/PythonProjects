def slow_down(delay):
    """ argumental decorators OR decorator with argument """
    def slow_down_handler(func):
        from time import sleep
        def wrapper_slow_down(*args): # from wrapper original function need to be called.
            sleep(delay)
            return func(*args)
    
        return wrapper_slow_down
    return slow_down_handler


@slow_down(.4)
def count_down(counter):    
    if counter:
        print(counter)
        count_down(counter - 1)
    else:
        print('lift-off...')    
        
#count_down = timer(slow_down(count_down))    

if __name__ == '__main__':
    print(count_down)
    count_down(5)