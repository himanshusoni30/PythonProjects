def debug(func):
    """decorators"""
    def wrapper_debug(*args):
        ret_value=func(*args) # decorated function
        print('called {}{} and returns {}'.format(func.__name__, args, ret_value))
        return ret_value
    
    return wrapper_debug

def to_json(func):
    """wrapper over return value of a function"""
    from json import dumps
    def wrapper_to_json(*args):
        value = func(*args)
        return dumps(value) #wrapper over return value of a function
    
    return wrapper_to_json

def to_integers(func):
    def wrapper_to_integers(*args):
        args = tuple(map(int, args))
        return func(*args)
    
    return wrapper_to_integers

@to_json    
@debug
@to_integers
def compute(a, b):
    return dict(result = a + b)
    
#compute = debug(compute)

if __name__ == '__main__':
    print(compute('11', 12))