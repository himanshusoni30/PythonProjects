def debug(func):
    """decorators"""
    def wrapper_debug(*args):
        ret_value=func(*args) # decorated function
        print('called {}{} and returns {}'.format(func.__name__, args, ret_value))
        return ret_value
    
    return wrapper_debug

@debug
def compute(a, b):
    return dict(result = a + b)
    
#compute = debug(compute)

if __name__ == '__main__':
    print(compute(11, 12))
