from os import listdir
from os.path import isfile, isdir, join, getsize, getmtime, basename
from time import ctime
from pprint import pprint as pp

class DirectoryListing:
    def __init__(self, *args):
        self.directories = args
        self.container = dict()
        self.__read_directories()
        
    def __read_directories(self):
        for dir_name in self.directories:
            generator_abs_path = (join(dir_name, item) for item in listdir(dir_name))
            
            for file_name in filter(isfile, generator_abs_path):
                file_properties = [getsize(file_name), ctime(getmtime(file_name))]
                file_name = basename(file_name)
                self.container.setdefault(dir_name, {})[file_name] = file_properties
                #setdefault is a method to create dictionary of dictionary

if __name__ == '__main__':
    dl = DirectoryListing('D:/Userfiles/hsoni/downloads')#D:\Userfiles\hsoni\Downloads
    pp(dl.container) 
