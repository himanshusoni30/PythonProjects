from OOPs.baseclassperson import Person

"""
class Employee(Person):
    #derived class
    pass

if __name__ == '__main__':
    em = Employee('guido','rossum')
    em.get_info()

"""

class Employee(Person):
    def __init__(self, eid, fn, ln):
        self.eid=eid
        super().__init__(fn,ln) #invoke overriden methods, object to invoke method of base class
        
    def get_info(self):
        print('employee id: ', self.eid)
        super().get_info()
        
if __name__ == '__main__':
    em = Employee('v0004','guido','rossum')
    em.get_info()