
class CustomConnectionError(Exception):
    """user defined exception"""
    pass

class Connectors:
    max_connections = 5
    connection_counter = 0
    
    def __init__(self, c_id):
        self.id = c_id
        Connectors.connection_counter += 1
        Connectors.check_limit() #calling the class method
        
    @classmethod        # '@' decorators in python like annotations in java
    def check_limit(cls):
        if cls.connection_counter > cls.max_connections   :
            raise CustomConnectionError('reached maximum allowed concurrent connection')
        
if __name__ == '__main__':
    try:
        for item in range(1, 7):
            print(Connectors(item))
    except CustomConnectionError as err:
        print(err)