from abc import abstractmethod, ABCMeta
from zipfile import ZipFile 
from tarfile import TarFile
from glob import glob

class BaseArchive(metaclass=ABCMeta):
    """abstract class"""    
    @abstractmethod
    def save(self):
        pass

class ZipArchive(BaseArchive):
    """concrete class"""
    
    def __init__(self,archive_name):
        self.archive_name = archive_name
    
    def save(self, *args):
        """overridden the abstract method"""
        with ZipFile(self.archive_name, mode='w') as zf: # context manager
            for file_name in args:
                zf.write(file_name)
                print(file_name, 'added')
                
class TarArchive(BaseArchive):
    pass

def make_archive(archive_name, *args, archive_type = 'zip'):
    """ factory method """
    if archive_type == 'zip':
        archive = ZipArchive(archive_name)
    elif archive_type == 'tar':
        archive = TarArchive(archive_name)
    
    archive.save(*args)
    
if __name__=='__main__':
    make_archive('pyfiles.zip', *glob('*.py'))