from json import load
from pprint import pprint as pp

content = load(open('tmp.json'))
pp(content)

for dir_name, file_items in content.items():
    print(dir_name)
    
    for file_name, file_prop in file_items.items():
        print("\t", file_name)
        
        for name, value in zip(['size', 'mtime'], file_prop):
            print("\t\t{} : {}".format(name, value))
            
            print()
        