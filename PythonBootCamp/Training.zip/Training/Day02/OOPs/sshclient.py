"""python ssh client"""
import paramiko
from glob import glob
from OOPs.factorymethod import make_archive
from getpass import getpass
""" dynamic way of getting the password """

class CustomSSHClient:
    def __init__(self, host, port, user, pwd):
        self.host = host
        self.port = port
        self.user = user
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(self.host, self.port, self.user, pwd)
        
    def check_output(self, job):
        stdin, stdout, stderr = self.ssh.exec_command(job)
        return stdout.read().decode('ascii') 
    """ convert bytes into unicode string """
        
    def upload(self, file_name):
        """sftp upload"""
        sftp = self.ssh.open_sftp()
        sftp.put(file_name, file_name)
        sftp.close()
        
    def __del__(self):
        self.ssh.close()
        
if __name__ == '__main__':
    archive='pdfs.zip'
    make_archive(archive, *glob('D:/Himanshu_Soni/PythonAdvancedTraining/WorkSpace/Training/*.py'))
    ssh = CustomSSHClient('ravijaya.info',22,'training','training') #ravijaya.info
    ssh.upload(archive)
    print('done uploading :', archive)
        