import pickle
from OOPs.derivedclassemployee import Employee

def serialize():
    """ serialize for object persistence """
    e = Employee('v004', 'guido', 'rossum')
    pickle.dump(e, open('employee.pickle','wb')) #wb write binary
    
def un_serialize():
    emp_obj=pickle.load(open('employee.pickle','rb')) #rb read binary
    emp_obj.get_info()
    
if __name__ == '__main__':
    serialize()
    un_serialize()