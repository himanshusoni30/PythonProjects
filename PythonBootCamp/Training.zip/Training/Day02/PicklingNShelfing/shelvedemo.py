import shelve

def serialize():
    with shelve.open('container.shelve') as sh:
        sh['cart'] = dict(toy=2, oneplus=1)
        sh['user'] = 'chintu'
        sh['area'] = 'bangalore'
        
def un_serialize():
    with shelve.open('container.shelve') as sh:
        for item, value in sh.items():
            print(item, '->', value)
    
if __name__ == '__main__':
    serialize()
    un_serialize()