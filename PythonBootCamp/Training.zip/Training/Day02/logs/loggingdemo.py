import logging

fmt_str = '%(asctime)s | %(levelname)s | %(name)s | %(filename)s | %(process)s | %(processName)s | %(message)s | %(relativeCreated)d'
logging.basicConfig(level=logging.DEBUG, format=fmt_str, filename='error.log')

if __name__ == '__main__':    

    logging.debug('debug messages')
    logging.info('confirmation notes')
    logging.warning('warnings messages')
    logging.error('error information')
    logging.critical('panic error')