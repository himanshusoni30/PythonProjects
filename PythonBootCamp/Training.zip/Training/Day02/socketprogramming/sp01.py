import socketserver
from time import ctime

class CustomRequestHandler(socketserver.BaseRequestHandler):
    def handle(self):
        """ invoked for the request """
        print('received request from ',self.client_address)
        ts = ctime().encode('ascii') #unicode into bytes
        self.request.sendall(ts)

class DayTimeServer:
    def __init__(self, server_address):
        self.server_address = server_address
        self.server = socketserver.TCPServer(self.server_address, CustomRequestHandler)
        self.server.serve_forever()
        
if __name__ == '__main__':
    DayTimeServer(('localhost', 8989))