import socket

try:
    server_addr = 'localhost', 8989
    sock = socket.socket()
    sock.connect(server_addr)
    content = sock.recv(1024)
    print(content)
finally:
    sock.close()