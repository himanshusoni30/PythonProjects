import sqlite3

conn = sqlite3.connect('sep28.sqlite')
cur = conn.cursor()
query = 'select sqlite_version()'
cur.execute(query)

print(cur.fetchone())   #to fetch a row from the resultset

cur.close()
conn.close()