import sqlite3

conn = sqlite3.connect('sep28.sqlite')
cur = conn.cursor()
query = """
create table if not exists task(
id integer primary key autoincrement,
title varchar(64),
description text,
status boolean)
"""

cur.execute(query)
conn.execute
# print(cur.fetchone())   #to fetch a row from the resultset

cur.close()
conn.close()