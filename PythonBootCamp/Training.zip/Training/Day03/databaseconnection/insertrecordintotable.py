import sqlite3
from pprint import pprint as pp

class TaskModel:
    def __init__(self, db_name=r'D:\Himanshu_Soni\PythonAdvancedTraining\WorkSpace\Training\Day03\databaseconnection\sep28.sqlite'):
        self.conn = sqlite3.connect(db_name)
        self.cur = self.conn.cursor()
        
    def fetch_tasks(self):
        self.cur.execute('select * from task')
        for row in self.cur.fetchall():
            yield row
            
    def fetch_task_by_id_as_dict(self, task_id):
        self.cur.execute('select * from task where id == {}'.format(task_id))
        list_of_column_names = [col_info[0] for col_info in self.cur.description]
        return [dict(zip(list_of_column_names, self.cur.fetchone()))]
            
    def fetch_tasks_as_dict(self):
        self.cur.execute('select * from task')
        list_of_column_names = [col_info[0] for col_info in self.cur.description]
        return [dict(zip(list_of_column_names, row)) for row in self.cur.fetchall()]
    
    def delete_task(self, task_id):
        self.cur.execute('delete from task where id =={}'.format(task_id))
        self.conn.commit()
        
    def create_task(self, title, description, status):
        query = 'insert into task (title, description, status) values (?, ?, ?)'
        self.cur.execute(query, [title, description, status])
        self.conn.commit()
        
    def insert_many(self, data_set):
        query = 'insert into task (title, description, status) values (?, ?, ?)'
        self.cur.executemany(query, data_set)
        self.conn.commit()
        
    def __del__(self):
        self.cur.close()
        self.conn.close()
        
if __name__ == '__main__':
    rows = [['Buy groceries', 'Milk, Cheese, frozen pizza, fruits', False],
            ['learn flask', 'find reference materials', False]]
    tm = TaskModel()
#     tm.insert_many(rows)
#     for task in tm.fetch_tasks():
#         print(task)
#     pp(tm.fetch_tasks_as_dict())
#     pp(tm.fetch_task_by_id_as_dict(2))
#     tm.create_task('todo list', 'write a todo list', False)
#     pp(tm.fetch_tasks_as_dict())
#     tm.delete_task(4)
    pp(tm.fetch_tasks_as_dict())
    
        