from flask import Flask
from time import ctime
from os import environ

app = Flask(__name__)

@app.route('/env')
def get_env():
    content=''
    for name, value in environ.items():
        content += '{:>22} : {}\n'.format(name, value)
    
    return '<pre>{}</pre>'.format(content)

@app.route('/ts')
def get_time():
    return '<h1>{}</h1>'.format(ctime())

@app.route('/')
def index():
    content = '<a href = "/ts">Current Timestamp</a>'
    content += '&nbsp;&nbsp;<a href="/env">env</a>'
    return content + '<h1><font color="blue">Hello & Hi</font></h1>'

if __name__ == '__main__':
    app.run(debug=True)