import requests
from pprint import pprint as pp

def get_tasks(task_id=None):
    if task_id:
        url = 'http://127.0.0.1:5000/todo/tasks/{}'.format(task_id)
    else:
        url = 'http://127.0.0.1:5000/todo/tasks'
    response = requests.get(url)
    pp(response.json())
    
def delete_task(task_id):
    url = 'http://127.0.0.1:5000/todo/tasks/{}'.format(task_id)
    response = requests.delete(url)
    print(response.status_code)
    print(response.json())
    
def post_create_task():
    url = 'http://127.0.0.1:5000/todo/tasks'
    payload = dict(title='post test', description = 'post training assessment', status=False)
    
    response = requests.post(url, json=payload)
    print(response.status_code)
#     print(response.json())
    
if __name__ == '__main__':
    get_tasks()
#     get_tasks(1)
#     delete_task(3)
#     get_tasks(2)
    post_create_task()