from flask import Flask, jsonify, request, abort
from databaseconnection.insertrecordintotable import TaskModel

app = Flask(__name__)

@app.route('/todo/tasks', methods=['POST'])
def create_task():
    if not request.json and 'title' in request.json:
        abort(400)
    title = request.json['title']
    description = request.json.get('description','')
    status = request.json.get('status', False)
    tm = TaskModel()
    tm.create_task(title,description,status)
    task = dict(title=title, description = description, status=status)
    return jsonify(dict(task=task))

@app.route('/todo/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    tm = TaskModel()
    tm.delete_task(task_id)
    return jsonify(dict(status='Success'))

@app.route('/todo/tasks/<int:task_id>', methods=['GET'])
def get_task(task_id):
    tm = TaskModel()
    tasks = {'tasks': tm.fetch_task_by_id_as_dict(task_id)}
    return jsonify(tasks)

@app.route('/todo/tasks', methods=['GET'])
def get_tasks():
    tm = TaskModel()
    tasks = {'tasks': tm.fetch_tasks_as_dict()}
    return jsonify(tasks)

if __name__ == '__main__':
    app.run(debug=True)