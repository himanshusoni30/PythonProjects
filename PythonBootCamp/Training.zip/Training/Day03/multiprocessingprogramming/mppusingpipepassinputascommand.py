import multiprocessing
from subprocess import check_output

def worker(rd, wt):
    job = rd.recv()
    response = check_output([job])
    wt.send(response.decode('ascii')) #bytes into unicode
    
def main():
    """parent process"""
    rd1,wt1 = multiprocessing.Pipe()
    rd2,wt2 = multiprocessing.Pipe()
    
    child = multiprocessing.Process(target=worker, args=(rd1, wt2))
    child.start()
    
    s = 'ipconfig'
    wt1.send(s)
    content = rd2.recv()
    
    print('sent : ',s)
    print('recv : ', content)
    
if __name__ == '__main__':
    main()