import multiprocessing
import requests
from requests.exceptions import ConnectionError
import smtplib
from email.mime.text import MIMEText

"""
response = requests.get('http://www.python.org')
print(response.headers)
print(response.status_code)
print(response.content)
"""
STMP_SERVER_ADDRESS = 'mucsmtp3.amadeus.net'

def send_alert_mail(from_addr, to_addr, subject, mail_message):
    mesg = MIMEText(mail_message)
    mesg['From']=from_addr
    mesg['To']=to_addr
    mesg['Subject']=subject
    
    smtp = smtplib.SMTP(STMP_SERVER_ADDRESS)
    smtp.sendmail(from_addr, to_addr, mesg.as_string())
    smtp.close()

def http_client(queue):
    """child process"""
    try:
        url = queue.get()   #to get an item from the queue
        p_name = multiprocessing.current_process().name
        response = requests.get(url)
        print('{}: {}: {}'.format(p_name, url, response.content[:128]))
    except ConnectionError as err:
        print(err)
        subject = '{}: {} failed http request'.format(p_name, url)
        send_alert_mail('himanshu.soni@amadeus.com', 'himanshu.soni@amadeus.com', subject, str(err))

def main():
    urls = ['http://www.python.org',
            'http://kernel.org',
            'http://linux.org',
            'http://www.perllang.org',
            'http://google.com']
    
    queue = multiprocessing.Queue()
    
    for url in urls:
        p = multiprocessing.Process(target=http_client, args=(queue,))
        p.start()
        
    for url in urls:
        queue.put(url) #adds url to the queue
        
if __name__ == '__main__':
    main()