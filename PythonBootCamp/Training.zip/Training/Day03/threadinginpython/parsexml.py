import xml.etree.ElementTree as et
doc = et.parse('host.xml')
print(doc)
print()
root_tag = doc.getroot()
print(root_tag)
print(root_tag.tag)