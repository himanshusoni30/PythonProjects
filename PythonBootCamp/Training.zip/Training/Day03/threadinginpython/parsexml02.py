import xml.etree.ElementTree as et
doc = et.parse('host.xml')
host_tags = doc.getiterator('host')
for host_tag in host_tags:
    print(host_tag.attrib)
    
    for config in host_tag:
        print("\t", config.tag, '->', config.text)