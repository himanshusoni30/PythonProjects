import threading
from time import sleep

def worker():
    """ thread function """
    t_id = threading.current_thread().ident
    t_name = threading.current_thread().name
    sleep(1)
    print(t_name, ':', t_id)
    
def main():
    """ main thread """
    list_of_threads = list()
    
    for item in range(1, 6):
        t = threading.Thread(target=worker)
        list_of_threads.append(t)
        t.start()
        
    for t in list_of_threads:
        t.join() 
        
        """
        blocked, joined thread terminates (join will block the execution of the main thread, 
        until the execution of child thread terminates)
        """
        
    print('main thread prepares to terminate')
    
if __name__ == '__main__':
    main()