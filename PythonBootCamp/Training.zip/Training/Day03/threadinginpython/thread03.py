import threading
from time import sleep
from random import random

def worker(delay):
    """ thread function """
    t_id = threading.current_thread().ident
    t_name = threading.current_thread().name
    sleep(delay)
    print(t_name, 'waited for :', delay)
    
def main():
    """ main thread """
    list_of_threads = list()
    
    for item in range(1, 6):
        rand_value = random()
        t = threading.Thread(target=worker, args=(rand_value,)) #pass arguments to thread
        list_of_threads.append(t)
        t.start()
        
    for t in list_of_threads:
        t.join() 
        
        """
        blocked, joined thread terminates (join will block the execution of the main thread, 
        until the execution of child thread terminates)
        """
        
    print('main thread prepares to terminate')
    
if __name__ == '__main__':
    main()