import threading
import xml.etree.ElementTree as et
from OOPs.sshclient import CustomSSHClient
import logging
from time import sleep

logging.basicConfig(format='%(threadName)s : %(message)s')
target_file = 'sshresponse.log'

def parse_host_config_file(host_file):
    doc=et.parse(host_file)
    
    for host_tag in doc.getiterator('host'):
        host_config = list()
        host_config.append(host_tag.get('name'))
        host_config.append(host_tag.get('port'))
        yield host_config + [info_tag.text for info_tag in host_tag]
        
class ThreadSSHHandler(CustomSSHClient):
    """ thread functionality """
    def __init__(self,host,port,user,pwd,job, lock):
        self.job=job
        self.lock = lock
        self.t_name=threading.current_thread().name
        super().__init__(host, port, user, pwd)
        self.__task_runner()
        
    def __task_runner(self):
        payload = self.check_output(self.job)
        
        caption = '{} ran {} @ {}'.format(self.t_name, self.job, self.host)
        
        logging.warning('waiting for the lock')
        with self.lock:
            logging.warning('acquired the lock')
            sleep(1)
            
            with open(target_file, 'a') as fw:
                """critical section, where race condition can occur, more than one thread try to acquire lock on object or file"""
                fw.write(caption.center(80, '-') + '\n')
                fw.write(payload)
            
            logging.warning('releases the lock')
        
class ThreadSSHClient:
    def __init__(self, host_config):
        self.config = host_config
        self.list_of_threads = list()
        self.lock = threading.Lock()
                
        for host_record in parse_host_config_file(self.config):
            host_record.append(self.lock)
            t = threading.Thread(target=ThreadSSHHandler, args=host_record)
            t.start()
            self.list_of_threads.append(t)
            #print(host_record)
            
        for t in self.list_of_threads:
            t.join()
            
if __name__ == '__main__':
    ThreadSSHClient('host.xml')